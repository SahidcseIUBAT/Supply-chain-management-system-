﻿//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
//using Microsoft.AspNetCore.Mvc.ModelBinding;
//using Microsoft.EntityFrameworkCore;
//using SupplyChainManagementSystem.Models;

//namespace SupplyChainManagementSystem.Data
//{
//    public class ApplicationDbContext : IdentityDbContext //DbContext
//    {
//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
//            : base(options)
//        {

//        }
//        public DbSet<Supplier> Suppliers { get; set; }
//        public DbSet<Product> Products { get; set; }
//        public DbSet<Warehouse> Warehouses { get; set; }
//        public DbSet<Inventory> Inventories { get; set; }
//        public DbSet<Order> Orders { get; set; }
//        public DbSet<Shipment> Shipments { get; set; }
//    }
//}

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SupplyChainManagementSystem.Models;

namespace SupplyChainManagementSystem.Data
{

    //  DbContext inherits from IdentityDbContext so Identity + your models share the same DB
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        //  Domain Models
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Warehouse> Warehouses { get; set; }
        public DbSet<Inventory> Inventories { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Shipment> Shipments { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Example: Product -> Supplier (many-to-one)
            builder.Entity<Product>()
                .HasOne(p => p.Supplier)
                .WithMany(s => s.Products)
                .HasForeignKey(p => p.SupplierId)
                .OnDelete(DeleteBehavior.Cascade);

            // Example: Inventory unique constraint (Product + Warehouse pair must be unique)
            builder.Entity<Inventory>()
                .HasIndex(i => new { i.ProductId, i.WarehouseId })
                .IsUnique();
        }

public DbSet<SupplyChainManagementSystem.Models.WarehouseSettings> WarehouseSettings { get; set; } = default!;
    }
}
