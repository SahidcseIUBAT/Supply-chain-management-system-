﻿using Microsoft.AspNetCore.Identity;

namespace SupplyChainManagementSystem.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Link user to a supplier (nullable: admins/warehouse staff may be null)
        public int? SupplierId { get; set; }
        public Supplier? Supplier { get; set; }
    }
}
