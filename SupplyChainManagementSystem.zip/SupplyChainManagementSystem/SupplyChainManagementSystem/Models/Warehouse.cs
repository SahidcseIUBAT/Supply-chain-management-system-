﻿using System.ComponentModel.DataAnnotations;

namespace SupplyChainManagementSystem.Models
{
    public class Warehouse
    {
        public int WarehouseId { get; set; }
        [Required] public string Name { get; set; } = null!;
        public string? Location { get; set; }

        public int CapacityTotal { get; set; } = 1000;
        public int AlertThresholdPercent { get; set; } = 90; // warn when >= this%

        public ICollection<Inventory>? Inventories { get; set; }
    }
}
