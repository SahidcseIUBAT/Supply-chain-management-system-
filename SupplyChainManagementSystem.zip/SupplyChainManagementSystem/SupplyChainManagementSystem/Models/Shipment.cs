﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SupplyChainManagementSystem.Models
{
    public enum ShipmentStatus { InTransit, Delivered, Cancelled }

    public class Shipment
    {
        public int ShipmentId { get; set; }
        public int OrderId { get; set; }
        public Order? Order { get; set; }

        public int ProductId { get; set; }
        public Product? Product { get; set; }

        public int FromSupplierId { get; set; } // supplier who shipped
        public Supplier? FromSupplier { get; set; }

        public int ToWarehouseId { get; set; }
        public Warehouse? ToWarehouse { get; set; }

        public int Quantity { get; set; }
        //public DateTime ShipmentDate { get; set; } = DateTime.UtcNow;

        //[Column(TypeName = "date")]
        //public DateTime ShipmentDay { get; set; } = DateTime.UtcNow.Date;

        public string? TrackingNumber { get; set; }
        public ShipmentStatus Status { get; set; } = ShipmentStatus.InTransit;
        public DateTime? ConfirmedAt { get; set; }
    }
}
