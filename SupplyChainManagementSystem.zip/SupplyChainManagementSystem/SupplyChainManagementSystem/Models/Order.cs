﻿using System.ComponentModel.DataAnnotations;

namespace SupplyChainManagementSystem.Models
{
    public enum OrderStatus { Pending, Approved, Rejected, Assigned, Shipped, Completed }

    public class Order
    {
        public int OrderId { get; set; }
        [Required] public string OrderNumber { get; set; } = Guid.NewGuid().ToString("N").Substring(0, 10);
        public int ProductId { get; set; } 
        public Product? Product { get; set; }

        public int Quantity { get; set; }

        // which supplier should handle this order (product has SupplierId too)
        public int SupplierId { get; set; }
        public Supplier? Supplier { get; set; }

        // target warehouse (where goods will be stored/received)
        public int WarehouseId { get; set; }
        public Warehouse? Warehouse { get; set; }
        //public OrderStatus Status { get; set; } = OrderStatus.Pending;

        public OrderStatus Status { get; set; } = OrderStatus.Pending;
        public string? RequestedByUserId { get; set; } // who created the order
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
