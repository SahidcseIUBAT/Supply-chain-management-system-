﻿using SupplyChainManagementSystem.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SupplyChainManagementSystem.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        [Required] 
        public string Name { get; set; } = null!;
        [Required] 
        public string SKU { get; set; } = null!;
        public string? Unit { get; set; }
        // owner supplier
        public int SupplierId { get; set; }
        public Supplier? Supplier { get; set; }

        public ICollection<Inventory>? Inventories { get; set; }
        public ICollection<Order>? Orders { get; set; }
    }
}