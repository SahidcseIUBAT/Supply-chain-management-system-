﻿using System.ComponentModel.DataAnnotations;

namespace SupplyChainManagementSystem.Models
{
    public class Supplier
    {
        public int SupplierId { get; set; }
        [Required] 
        public string Name { get; set; } = null!;
        public string? ContactInfo { get; set; }
        public ICollection<Product>? Products { get; set; }
        public ICollection<ApplicationUser>? Users { get; set; }
    }
}
