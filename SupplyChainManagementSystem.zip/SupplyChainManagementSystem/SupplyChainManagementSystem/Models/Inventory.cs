﻿using System.ComponentModel.DataAnnotations;

namespace SupplyChainManagementSystem.Models
{
    public class Inventory
    {
        public int InventoryId { get; set; }
        public int WarehouseId { get; set; }
        public Warehouse? Warehouse { get; set; }
        public int ProductId { get; set; }
        public Product? Product { get; set; }

        [Range(0, int.MaxValue)]
        public int Quantity { get; set; } = 0;

        // optimistic concurrency
        [Timestamp]
        public byte[]? RowVersion { get; set; }
    }
}
