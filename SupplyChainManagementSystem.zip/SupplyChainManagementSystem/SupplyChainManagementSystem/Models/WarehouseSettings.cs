﻿namespace SupplyChainManagementSystem.Models
{
    public class WarehouseSettings
    {
        public int WarehouseSettingsId { get; set; }
        public int CapacityTotal { get; set; } = 1000;
        public int AlertThresholdPercent { get; set; } = 90;
    }
}
