﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SupplyChainManagementSystem.Data;
using SupplyChainManagementSystem.Models;

namespace SupplyChainManagementSystem.Controllers
{
    public class WarehouseSettingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public WarehouseSettingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: WarehouseSettings
        public async Task<IActionResult> Index()
        {
            return View(await _context.WarehouseSettings.ToListAsync());
        }

        // GET: WarehouseSettings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var warehouseSettings = await _context.WarehouseSettings
                .FirstOrDefaultAsync(m => m.WarehouseSettingsId == id);
            if (warehouseSettings == null)
            {
                return NotFound();
            }

            return View(warehouseSettings);
        }

        // GET: WarehouseSettings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: WarehouseSettings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("WarehouseSettingsId,CapacityTotal,AlertThresholdPercent")] WarehouseSettings warehouseSettings)
        {
            if (ModelState.IsValid)
            {
                _context.Add(warehouseSettings);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(warehouseSettings);
        }

        // GET: WarehouseSettings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var warehouseSettings = await _context.WarehouseSettings.FindAsync(id);
            if (warehouseSettings == null)
            {
                return NotFound();
            }
            return View(warehouseSettings);
        }

        // POST: WarehouseSettings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("WarehouseSettingsId,CapacityTotal,AlertThresholdPercent")] WarehouseSettings warehouseSettings)
        {
            if (id != warehouseSettings.WarehouseSettingsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(warehouseSettings);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WarehouseSettingsExists(warehouseSettings.WarehouseSettingsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(warehouseSettings);
        }

        // GET: WarehouseSettings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var warehouseSettings = await _context.WarehouseSettings
                .FirstOrDefaultAsync(m => m.WarehouseSettingsId == id);
            if (warehouseSettings == null)
            {
                return NotFound();
            }

            return View(warehouseSettings);
        }

        // POST: WarehouseSettings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var warehouseSettings = await _context.WarehouseSettings.FindAsync(id);
            if (warehouseSettings != null)
            {
                _context.WarehouseSettings.Remove(warehouseSettings);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool WarehouseSettingsExists(int id)
        {
            return _context.WarehouseSettings.Any(e => e.WarehouseSettingsId == id);
        }
    }
}
