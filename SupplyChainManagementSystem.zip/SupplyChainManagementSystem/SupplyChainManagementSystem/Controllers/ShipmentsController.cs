﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SupplyChainManagementSystem.Data;
using SupplyChainManagementSystem.Models;

namespace SupplyChainManagementSystem.Controllers
{
    public class ShipmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ShipmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Shipments
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Shipments.Include(s => s.FromSupplier).Include(s => s.Order).Include(s => s.Product).Include(s => s.ToWarehouse);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Shipments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var shipment = await _context.Shipments
                .Include(s => s.FromSupplier)
                .Include(s => s.Order)
                .Include(s => s.Product)
                .Include(s => s.ToWarehouse)
                .FirstOrDefaultAsync(m => m.ShipmentId == id);
            if (shipment == null)
            {
                return NotFound();
            }

            return View(shipment);
        }

        // GET: Shipments/Create
        public IActionResult Create()
        {
            ViewData["FromSupplierId"] = new SelectList(_context.Suppliers, "SupplierId", "Name");
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderNumber");
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "Name");
            ViewData["ToWarehouseId"] = new SelectList(_context.Warehouses, "WarehouseId", "Name");
            return View();
        }

        // POST: Shipments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ShipmentId,OrderId,ProductId,FromSupplierId,ToWarehouseId,Quantity,ShipmentDate,ShipmentDay,TrackingNumber,Status,ConfirmedAt")] Shipment shipment)
        {
            if (ModelState.IsValid)
            {

                shipment.Status = ShipmentStatus.InTransit;
                
                shipment.ConfirmedAt = DateTime.UtcNow.Date;
                _context.Add(shipment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FromSupplierId"] = new SelectList(_context.Suppliers, "SupplierId", "Name", shipment.FromSupplierId);
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderNumber", shipment.OrderId);
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "Name", shipment.ProductId);
            ViewData["ToWarehouseId"] = new SelectList(_context.Warehouses, "WarehouseId", "Name", shipment.ToWarehouseId);
            return View(shipment);
        }

        // GET: Shipments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var shipment = await _context.Shipments.FindAsync(id);
            if (shipment == null)
            {
                return NotFound();
            }
            ViewData["FromSupplierId"] = new SelectList(_context.Suppliers, "SupplierId", "Name", shipment.FromSupplierId);
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderNumber", shipment.OrderId);
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "Name", shipment.ProductId);
            ViewData["ToWarehouseId"] = new SelectList(_context.Warehouses, "WarehouseId", "Name", shipment.ToWarehouseId);
            return View(shipment);
        }

        // POST: Shipments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ShipmentId,OrderId,ProductId,FromSupplierId,ToWarehouseId,Quantity,ShipmentDate,ShipmentDay,TrackingNumber,Status,ConfirmedAt")] Shipment shipment)
        {
            if (id != shipment.ShipmentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    shipment.ConfirmedAt = DateTime.UtcNow.Date;
                    _context.Update(shipment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ShipmentExists(shipment.ShipmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FromSupplierId"] = new SelectList(_context.Suppliers, "SupplierId", "Name", shipment.FromSupplierId);
            ViewData["OrderId"] = new SelectList(_context.Orders, "OrderId", "OrderNumber", shipment.OrderId);
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "Name", shipment.ProductId);
            ViewData["ToWarehouseId"] = new SelectList(_context.Warehouses, "WarehouseId", "Name", shipment.ToWarehouseId);
            return View(shipment);
        }
        // POST: Shipments/Approve/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            var shipment = await _context.Shipments.FindAsync(id);
            if (shipment == null) return NotFound();

            shipment.Status = ShipmentStatus.Delivered;  // adjust enum value as per your model
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }


        // GET: Shipments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var shipment = await _context.Shipments
                .Include(s => s.FromSupplier)
                .Include(s => s.Order)
                .Include(s => s.Product)
                .Include(s => s.ToWarehouse)
                .FirstOrDefaultAsync(m => m.ShipmentId == id);
            if (shipment == null)
            {
                return NotFound();
            }

            return View(shipment);
        }

        // POST: Shipments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var shipment = await _context.Shipments.FindAsync(id);
            if (shipment != null)
            {
                _context.Shipments.Remove(shipment);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ShipmentExists(int id)
        {
            return _context.Shipments.Any(e => e.ShipmentId == id);
        }
    }
}
